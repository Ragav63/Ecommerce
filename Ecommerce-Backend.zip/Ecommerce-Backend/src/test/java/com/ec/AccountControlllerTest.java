package com.ec;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.ec.MamsEcomApplication;
import com.ec.proj.Entity.Accounts;
import com.ec.proj.Service.AccountService;

@SpringBootTest(classes = MamsEcomApplication.class)
class AccountControlllerTest {
	@Autowired
	private AccountService accountService;
	static Accounts accounts;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		accounts=new Accounts();
		accounts.setAccountId(3);
		accounts.setFirstName("Raga");
		accounts.setLastName("A");
		accounts.setAccountEmail("ragav@gmail.com");
		accounts.setAccountPhone("9999444490");
		accounts.setAddress("Tiruvannamalai, Tamil Nadu");
		accounts.setFavourite("Red");
		accounts.setAccountPassword("raga@1234");
		accounts.setAccountCreatedDate(null);
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		assertNotNull(accountService.saveAcc(accounts));
	}
	
	@Test
	void testGetAllAccounts() {
		assertNotNull(accountService.findAllAccounts());
	}
	
	@Test
	void testGetByUsername() {
		assertNotNull(accountService.findbyusername("arulragavendiran@gmail.com","Raga@123"));
	}
	
	@Test
	void testGetByEmail() {
		assertNotNull(accountService.findByEmail("arulragavendiran@gmail.com"));
	}
	
}
