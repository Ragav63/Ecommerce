package com.ec;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ec.proj.Entity.Customer;
import com.ec.proj.Service.CustomerService;

class CustomerControllerTest {
	@Autowired
	private CustomerService customerService;
	static Customer customer;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		customer=new Customer();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
