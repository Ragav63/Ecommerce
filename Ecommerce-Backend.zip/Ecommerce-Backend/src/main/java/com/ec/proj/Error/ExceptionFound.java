package com.ec.proj.Error;

public class ExceptionFound extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public  ExceptionFound(String s) {
		super(s);
	}

}
